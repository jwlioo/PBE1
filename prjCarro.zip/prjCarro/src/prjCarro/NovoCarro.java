package prjCarro;

import java.util.Scanner;

public class NovoCarro {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		Carro carro01 = new Carro();
		Carro carro02 = new Carro("W","GOL",0);
		Carro carro03 = new Carro("Toyota");
		
		
		System.out.println("Qual a marca? ");
		
		carro01.setMarca ( sc.nextLine());
		
		System.out.println("Qual o modelo?");
		carro01.setModelo ( sc.nextLine());
		
		System.out.println("Qual a velocidade?");
		carro01.velocidade = sc.nextInt();
		
		
		System.out.println("opcoes:");
		System.out.println("acelerar");
		System.out.println("frear");
		System.out.println("buzinar");
		System.out.println("escolha uma opcao: ");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto voce quer acelerar?");
			carro01.acelerar(sc.nextInt());
		}
		else if (escolha ==2) {
			System.out.println("Quanto voce quer desacelerar?");
			carro01.frear(sc.nextInt());
			
		}else if(escolha ==3) {
			carro01.buzinar();
		}
		else {
			System.out.println("opcao invalida");
			
		}
		System.out.println("marca "+carro01.getMarca());
		System.out.println("modelo "+carro01.getModelo());
		System.out.println("velocidade "+carro01.getVelocidade());
	}

}
