package prjContaBancaria;

public class Conta {
	//atributos
			private int numeroConta;
			private String nomeTitular;
			private double saldoAtual;
			
			//construtores
				public Conta() {
					
				}
				public Conta(int numeroConta,String nomeTitular,double saldoAtual){
					this.numeroConta = numeroConta;
					this.nomeTitular = nomeTitular;
					this.saldoAtual = saldoAtual;
				}
				
				
				//getters setters
				public int getNumeroConta() {
					return numeroConta;
				}
				public void setMarca(int numeroConta) {
				this.numeroConta = numeroConta;
			
				}
				public String getModelo() {
					return this.modelo;
				}
				public void setModelo(String modelo) {
					this.modelo = modelo;
				}
				
				public int getVelocidade() {
					return velocidade;
				}
				public void setvelocidade(int velocidade) {
					if(velocidade < 0) {
						System.out.println("velocidade nao pode ser negativa!");
						this.velocidade=0;
					}
					else {
						this.velocidade = velocidade;
					
	
}
