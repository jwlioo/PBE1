package prjExercio03;

public class leao {

	public class Leao extends Animal{
		public Leao(String string, int i, String string2) {
			// TODO Auto-generated constructor stub
		}

		//metodo da SubClasse
		public void cacar() {
			System.out.println("o leao" + getNome() + "esta caçando");
		}
	}
		public void metodoEmitirSom() {
			System.out.println("RUAARRR");
			
		}


	}


	

