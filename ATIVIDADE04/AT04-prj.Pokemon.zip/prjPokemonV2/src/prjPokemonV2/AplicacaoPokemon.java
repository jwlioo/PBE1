package prjPokemonV2;

public class AplicacaoPokemon {

	public static void main(String[] args) {
		PokemonFogo charmander = new PokemonFogo("Charmander", 5, "atacar");
		PokemonFogo vulpix = new PokemonFogo("Vulpix", 7, "atacar");

		PokemonVoador pidgey = new PokemonVoador("Pidgey", 3, "atacar");
		PokemonVoador zubat = new PokemonVoador("Zubat", 4, "atacar");

		PokemonAgua squirtle = new PokemonAgua("Squirtle", 6, "atacar");
		PokemonAgua psyduck = new PokemonAgua("Psyduck", 8, "atacar");

		// Exibindo informações e atacando
		charmander.setNivel(5);
		charmander.setHp(100);
		charmander.defesa(50);
		charmander.metodoAtacar();
		charmander.exibirinfo();
		

		System.out.println("\n");

		
		vulpix.setHp(100);
		vulpix.setNivel(7);
		vulpix.defesa(50);
		vulpix.metodoAtacar();
		vulpix.exibirinfo();
		System.out.println("\n");

		
		pidgey.setHp(100);
		pidgey.setNivel(3);
		pidgey.defesa(50);
		pidgey.metodoAtacar();
		pidgey.exibirinfo();
		System.out.println("\n");

		
		zubat.setHp(100);
		zubat.setNivel(4);
		zubat.defesa(50);
		zubat.metodoAtacar();
		zubat.exibirinfo();
		System.out.println("\n");

		
		squirtle.setHp(100);
		squirtle.setNivel(6);
		squirtle.defesa(50);
		squirtle.metodoAtacar();
		squirtle.exibirinfo();
		System.out.println("\n");

		
		psyduck.setHp(100);
		psyduck.setNivel(8);
		psyduck.defesa(50);
		psyduck.metodoAtacar();
		psyduck.exibirinfo();

	}

	

}
