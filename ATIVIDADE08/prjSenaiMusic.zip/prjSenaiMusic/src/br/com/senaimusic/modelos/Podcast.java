package br.com.senaimusic.modelos;

public class Podcast extends Audio {
	//atributos
	private String apresentador;
	private String descricao;
	
	//getter e setters
	public String getApresentador(){
		return this.apresentador;
	}
	public void setApresentador(String apresentador) {
		this.apresentador = apresentador;
		
	}
	public String getDescricao(){
		return this.descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;		
	}
	
	@Override
	public double getClassificacao() {
		if (this.getTotalCurtidas() > 500) {
			return 10;
		}else {
			return 8;
		}
		
	}
}
