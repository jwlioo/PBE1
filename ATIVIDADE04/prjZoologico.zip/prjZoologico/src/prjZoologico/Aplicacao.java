package prjZoologico;

public class Aplicacao {

	public static void main(String[] args) {
		ClasseAnimal elefante = new ClasseAnimal() ;
		elefante.setNome("Dumbo");
		elefante.setPeso(100);
		
		
		
		
		
		
		
		
		
		
			
			ClasseAnimal girafa = new ClasseAnimal("girafa", "russa", "femea",128);
			
			SubClasseCarnivoro leao = new SubClasseCarnivoro();
			leao.atributoNome = "Simba";
			leao.atributoRaca = "Australiano";
			leao.atributoSexo = "macho";
			leao.atributoPeso = 128;
			
			SubClasseReptil cobra = new SubClasseReptil();
			cobra.atributoNome = "Ana Conda";
			cobra.atributoRaca = "anaconda";
			cobra.atributoSexo = "femea";
			cobra.atributoPeso = 128;
			
			
			
			elefante.exibirInfo();
			elefante.metodoComer(50);
			elefante.exibirInfo();
			elefante.metodoEmitirSom();
			
			System.out.println("\n");
			
			leao.exibirInfo();
			leao.metodoComer();
			leao.exibirInfo();
			leao.metodoEmitirSom();
			
			System.out.println("\n");
			
			girafa.exibirInfo();
			girafa.metodoComer();
			girafa.exibirInfo();
			girafa.metodoEmitirSom();
			
			System.out.println("\n");
			
			cobra.exibirInfo();
			cobra.metodoComer();
			cobra.exibirInfo();
			cobra.metodoTrocarPele();
			cobra.metodoRastejar();
			cobra.metodoEmitirSom();
			
			
			
	
		

	}

}
