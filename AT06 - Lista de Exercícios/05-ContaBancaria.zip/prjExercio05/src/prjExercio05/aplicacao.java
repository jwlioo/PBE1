package prjExercio05;

import java.util.Scanner;

public class aplicacao {
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Conta conta01 = new Conta();
		
		
		System.out.println("informe o numero da conta bancaria: ");
		conta01.setNumeroConta(sc.nextInt());
		System.out.println("informe o nome do titular da conta: ");
		conta01.setNomeTitular ( sc.next());
		System.out.println("qual o saldo atual da conta?: ");
		conta01.setSaldoAtual(sc.nextDouble());
		
		
		System.out.println("opcoes:");
		System.out.println("1.depositar");
		System.out.println("2.sacar");
		System.out.println("3.ver saldo da conta bancaria");
		System.out.println("escolha uma opcao: ");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto voce quer depositar?");
			conta01.depositar (sc.nextInt());
		}
		else if (escolha ==2) {
			System.out.println("Quanto voce quer sacar?");
			conta01.sacar(sc.nextInt());
			
		}else if (escolha ==3) {
			System.out.println("o saldo da sua conta bancaria é: ");
			
		}
		else {
			System.out.println("opcao invalida");
			
		}
		System.out.println("numero da conta bancaria: "+conta01.getNumeroConta());
		System.out.println("nome do titular da conta: "+conta01.getNomeTitular());
		System.out.println("saldo atual da conta: "+conta01.getSaldoAtual());

	}

}



