package prjPokemonV2;

public class PokemonVoador extends Pokemon {
	public PokemonVoador(String nome, int nivel, String ataque) {
		this.setNome(nome);
	}

	public void metodoVoar() {

		System.out.println(this.getTipo() + " Está voando");
	}

	public void metodoAtaquedeAsa() {
		System.out.println(this.getNome() + "Atacou!");
	}

	@Override
	public void metodoAtacar() {
		System.out.println("Atacou voando");
	}

}
