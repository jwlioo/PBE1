package prjCarro;

import java.util.Scanner;

public class andardeCarro {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		4
		
		
		
		System.out.println("Qual a marca do carro? ");
		String marcacarro = sc.nextLine();
		
		
		System.out.println("qual o modelo do carro? ");
		String modelo = sc.nextLine();
		 
		 System.out.println("qual a velocidade do carro? ?");
		 int velocidade= sc.nextInt();
		 
		 System.out.println("Se voce quer acelerar digite 1  ou se quer frear digite 2 ");
		int aceleraroufrear = sc.nextInt();
		
		System.out.println("Opçoes:");
		System.out.println("1. acelerar");
		System.out.println("2 Frear");
		System.out.println("escolha uma opçao: ");
		
		int escolha = sc.nextInt();
		
		
		
	
		
		if(escolha == 1 ) {
			System.out.println("O quanto voce quer acelerar? ");
			int valor = sc.nextInt();
			velocidade += valor;
			}
		
		else if {
			System.out.println("Quanto voce quer desacelerar?: ");
			int valor= sc.nextInt();
			velocidade -= valor;
		}
		else {
			System.out.println("opcao invalida");
			
	}
	
		
				
		 
	
		 
		 
		
		 
		

	}

}
