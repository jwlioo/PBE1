package prjExercio02;


	public class Livro {
	    // Atributos
	    private String titulo;
	    private String autor;
	    private int numPaginas;
	    private double preco;

	    // Construtor padrão (sem parâmetros)
	    public Livro() {
	    }

	    // Construtor parametrizado
	    public Livro(String titulo, String autor, int numPaginas, double preco) {
	        this.titulo = titulo;
	        this.autor = autor;
	        this.numPaginas = numPaginas;
	        this.preco = preco;
	    }

	    // Getters
	    public String getTitulo() {
	        return titulo;
	    }

	    public String getAutor() {
	        return autor;
	    }

	    public int getNumPaginas() {
	        return numPaginas;
	    }

	    public double getPreco() {
	        return preco;
	    }

	    // Setters
	    public void setTitulo(String titulo) {
	        this.titulo = titulo;
	    }

	    public void setAutor(String autor) {
	        this.autor = autor;
	    }

	    public void setNumPaginas(int numPaginas) {
	        this.numPaginas = numPaginas;
	    }

	    public void setPreco(double preco) {
	        this.preco = preco;
	    }

	    // Método para aplicar desconto 
	    public void aplicarDesconto() {
	        if (this.preco > 15) {
	            this.preco -= 15;
	        } else {
	            System.out.println("O preço do livro é muito baixo para aplicar o desconto.");
	        }
	    }

	    // Método para exibir inf
	    public void exibirInfo() {
	        System.out.println("Título: " + titulo);
	        System.out.println("Autor: " + autor);
	        System.out.println("Número de Páginas: " + numPaginas);
	        System.out.println("Preço: R$" + String.format("%.2f", preco));
	        System.out.println();
	    }
	}
