package br.com.bibiotecasenai.usuarios;

public class Pessoa {
	//atributos
	private String Nome;
	private int idade;
	
	// metodos
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
