package prjCarro;

public class Carro {


		//atributos
		private String marca;
		private String modelo;
		private int velocidade;
		
		//construtores
			public Carro() {
				
			}
			
			public Carro(String marca,String modelo,int velocidade){
				this.marca = marca;
				this.modelo = modelo;
				this.velocidade = velocidade;
			}
		public Carro(String marca) {
			this.marca = marca;
					
		}
		//getters setters
		public String getMarca() {
			return marca;
		}
		public void setMarca(String marca) {
		this.marca = marca;
	
		}
		public String getModelo() {
			return this.modelo;
		}
		public void setModelo(String modelo) {
			this.modelo = modelo;
		}
		
		public int getVelocidade() {
			return velocidade;
		}
		public void setvelocidade(int velocidade) {
			if(velocidade < 0) {
				System.out.println("velocidade nao pode ser negativa!");
				this.velocidade=0;
			}
			else {
				this.velocidade = velocidade;
			}
						
		}
				
		//metodos
		void acelerar(int acelerar) {
			velocidade += acelerar;
		
		}
		void frear (int reduzir) {
			velocidade -= reduzir;
		}
		void buzinar() {
			System.out.println("bibi fonfon");
		}

	}


