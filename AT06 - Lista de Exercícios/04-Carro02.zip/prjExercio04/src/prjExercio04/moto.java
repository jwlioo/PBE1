package prjExercio04;

public class moto {

}
