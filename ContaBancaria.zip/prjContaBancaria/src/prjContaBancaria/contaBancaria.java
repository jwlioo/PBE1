package prjContaBancaria;

import java.util.Scanner;

public class contaBancaria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		
		System.out.println("informe o numero da conta bancaria: ");
		int numeroConta = sc.nextInt();
		System.out.println("informe o nome do titular da conta: ");
		int nomeTitular = sc.nextInt();
		System.out.println("qual o saldo atual da conta?: ");
		double saldo = sc.nextInt();
		
		
		System.out.println("opcoes:");
		System.out.println("1.depositar");
		System.out.println("2.sacar");
		System.out.println("3.ver saldo da conta bancaria");
		System.out.println("escolha uma opcao: ");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto voce quer depositar?");
			(sc.nextInt());
		}
		else if (escolha ==2) {
			System.out.println("Quanto voce quer sacar?");
			(sc.nextInt());
			
		}else if (escolha ==3) {
			System.out.println("o saldo da sua conta bancaria é: "+);
			
		}
		else {
			System.out.println("opcao invalida");
			
		}

	}

}
