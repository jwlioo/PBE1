package br.com.senaimusic.modelos;

public class MinhasPreferidas {
	
	public void incluir(Audio audio) {
		if(audio.getClassificacao() >=9 ) {
			System.out.println("eta bixa boa emm");
		}else {
			System.out.println("eta bixa ruim");
		}
		
	}

	
		
}
