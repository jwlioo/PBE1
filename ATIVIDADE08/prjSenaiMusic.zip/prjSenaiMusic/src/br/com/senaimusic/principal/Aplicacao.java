package br.com.senaimusic.principal;

import br.com.senaimusic.modelos.MinhasPreferidas;
import br.com.senaimusic.modelos.Musica;
import br.com.senaimusic.modelos.Podcast;

public class Aplicacao {

	public static void main(String[] args) {
		Musica musica01 = new Musica();
		musica01.setTitulo("first love");
		musica01.setCantor("Bruno & Marrone");
		
		for(int i = 0; i < 1000; i++ ) {
		musica01.reproduz();
		}
		for(int i = 0; i < 50;i++) {
			musica01.curte();
		}
		Podcast podcast01 = new Podcast();
		podcast01.setTitulo("Podpah");
		podcast01.setApresentador("Leandromeda");
		
		for(int i = 0; i < 5000; i++) {
			podcast01.reproduz();
		}
		for(int i = 0; i < 4900;i++) {
			podcast01.curte();
		}
		System.out.println("A musica "+ musica01.getTitulo() + " tem a classificacao "+ musica01.getClassificacao());
		
		System.out.println("O podCast "+ podcast01.getTitulo()+ " tem a classificacao "+ podcast01.getClassificacao());
		
		MinhasPreferidas soAsReliquias = new MinhasPreferidas();
		soAsReliquias.incluir(podcast01);
		soAsReliquias.incluir(musica01);
		
		
		
	}
}