package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	
	private String matricula;
	
	//metodos
	
	public void realizarEmprestimo(String nomeLivro) {
		System.out.println(getNome() + ", realizou emprestimo do livro: " + nomeLivro);
		
	}
	public void devolverLivro(String nomeLivro) {
		System.out.println(getNome() + ", devolveu o livro: "+ nomeLivro);
		
	}
}
