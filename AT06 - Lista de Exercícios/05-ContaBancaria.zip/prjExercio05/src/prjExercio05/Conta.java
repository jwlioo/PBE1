package prjExercio05;

public class Conta {
	// Atributos
		private int numeroConta;
		private String nomeTitular;
		private double saldoAtual;

		// Construtores
		public Conta() {
		}

		public void Conta(int numeroConta, String nomeTitular, double saldoAtual) {
			this.numeroConta = numeroConta;
			this.nomeTitular = nomeTitular;
			this.saldoAtual = saldoAtual;
		}

		public int getNumeroConta() {
			return numeroConta;
		}

		public void setNumeroConta(int numeroConta) {
			this.numeroConta = numeroConta;
		}

		public String getNomeTitular() {
			return nomeTitular;
		}

		public void setNomeTitular(String nomeTitular) {
			this.nomeTitular = nomeTitular;
		}

		public double getSaldoAtual() {
			return saldoAtual;
		}

		public void setSaldoAtual(double saldoAtual) {
			this.saldoAtual = saldoAtual;
		}

		// metodos
		void depositar(int depositar) {
			numeroConta += depositar;

		}

		void sacar(int sacar) {
			numeroConta -= sacar;
		}

		void saldo() {
			System.out.println("o seu saldo atual é");
		}

	}


