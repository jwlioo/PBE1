package prjZoologico;

public class ClasseAnimal {
	//Atributos
	private String atributoNome;
	private String atributoRaca;
	private String atributoSexo;
	private double atributoPeso;
	//construtores
	
	public ClasseAnimal () {
		
		
	}
	public ClasseAnimal (String parametroNome,String parametroRaca,String parametroSexo, double parametroPeso) {
		this.atributoNome = parametroNome;
		this.atributoSexo = parametroSexo;
		this.atributoRaca = parametroRaca;
		this.atributoPeso = parametroPeso;
		
	}
	
	//Setters 
	public void setNome(String parametroNome) {
		this.atributoNome = parametroNome;
	}
		public void setPeso(double parametroPeso) {
			if(parametroPeso > 0) {
			this.atributoPeso = parametroPeso;
		}
			else {
				this.atributoPeso = 10;
			}
		}
			public String getAtributoNome() {
				return atributoNome;
			}
			public void setAtributoNome(String atributoNome) {
				this.atributoNome = atributoNome;
			}
			public String getAtributoRaca() {
				return atributoRaca;
			}
			public void setAtributoRaca(String atributoRaca) {
				this.atributoRaca = atributoRaca;
			}
			public String getAtributoSexo() {
				return atributoSexo;
			}
			public void setAtributoSexo(String atributoSexo) {
				this.atributoSexo = atributoSexo;
			}
			public double getAtributoPeso() {
				return atributoPeso;
			}
			public void setAtributoPeso(double atributoPeso) {
				this.atributoPeso = atributoPeso;
			}
	
	
	
	//metodos
		public void metodoComer() {
			if(this.atributoPeso >= 170)
				System.out.println(this.atributoNome + ", esta obeso, vamos exercitar");
			else {
				this.atributoPeso = this.atributoPeso + 10;
			}
			
		}
			
			public void metodoComer(int parametroRacao) {
				if(this.atributoPeso >= 170)
					System.out.println(this.atributoNome + ", esta obeso, vamos exercitar");
				else {
				 this.atributoPeso += parametroRacao;
			
		}
			}
		public void metodoExercitar() {
			if (this.atributoPeso <= 50)
				System.out.println(this.atributoNome + ",esta magro demais que tal comer?");
	
			else {
				this.atributoPeso += 10;}
			}
			public void exibirInfo() {
				System.out.println("nome: "+ this.atributoNome);
				System.out.println("peso: "+ this.atributoPeso);
		
		}
			public void metodoEmitirSom() {
				System.out.println("Barulho do bixinho");
			}
			
}
