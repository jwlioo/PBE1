package prjExercio03;

import prjExercio03.leao.Leao;

public class Aplicacao {

	
	    public static void main(String[] args) {
	        // Criando instâncias de Baleia e Leao
	        baleia baleia = new baleia("Baleia Azul", 5, "Baleia");
	        Leao leao = new Leao("Simba", 3, "Leão Africano");

	        // Testando os métodos
	        System.out.println("Testando a Baleia:");
	        baleia.fazerSom();  // O animal fez um som.
	        baleia.nadar();     // A baleia Baleia Azul está nadando.

	        System.out.println("Testando o Leão:");
	        leao.fazerSom();    // O animal fez um som.
	        leao.cacar();       // O leão Simba está

	}

}
