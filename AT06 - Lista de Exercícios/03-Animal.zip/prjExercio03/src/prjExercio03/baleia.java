package prjExercio03;

public class baleia {

	public class baleia extends Animal{
		//metodo da SubClasse
		public void nadar() {
			System.out.println("A baleia" + getNome() + "esta nadando");
		}
	}

	public baleia(String string, int i, String string2) {
		// TODO Auto-generated constructor stub
	}

	public void fazerSom() {
		System.out.println("A baleia" + getNome() + "esta fazendo som");
		
	}

	
}
		