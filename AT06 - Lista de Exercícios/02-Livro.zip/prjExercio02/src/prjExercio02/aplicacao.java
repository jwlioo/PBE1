package prjExercio02;

public class aplicacao {
	public static void main(String[] args) {
        // Criando três objetos de Livro
        Livro livro1 = new Livro("Dom Quixote", "Miguel de Cervantes", 1023, 59.90);
        Livro livro2 = new Livro("1984", "George Orwell", 328, 45.00);
        Livro livro3 = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien", 1200, 89.90);

        // Exibindo informações antes do desconto
        System.out.println("Informações antes do desconto:");
        livro1.exibirInfo();
        livro2.exibirInfo();
        livro3.exibirInfo();

        // Aplicando desconto fixo de 15 reais em todos os livros
        livro1.aplicarDesconto();
        livro2.aplicarDesconto();
        livro3.aplicarDesconto();

        // Exibindo informações após o desconto
        System.out.println("Informações após o desconto:");
        livro1.exibirInfo();
        livro2.exibirInfo();
        livro3.exibirInfo();
    }
}