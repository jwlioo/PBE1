package prjZoologico;

public class SubClasseReptil extends ClasseAnimal{
	//metodo da SubClasse
		public void metodoTrocarPele() {
			System.out.println(this.atributoNome + " esta trocando de pele.");
		}
		
		public void metodoRastejar() {
			System.out.println(this.atributoNome + " esta rastejando.");
		}
		@Override
		public void metodoEmitirSom() {
			System.out.println("shisisisisi");
}
}