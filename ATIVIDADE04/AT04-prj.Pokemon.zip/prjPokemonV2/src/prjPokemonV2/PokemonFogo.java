package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	public PokemonFogo(String nome, int nivel, String ataque) {

		this.setNome(nome);
	}

	public void metodoBolaFogo() {

		System.out.println(this.getTipo() + " Está lançando bola de fogo");
	}

	public void metodoExplosaoFogo() {
		System.out.println(this.getNome() + " Atacou com explosão de fogo!");
	}

	public void metodoLancaChamas() {
		System.out.println(this.getNome() + " Atacou com lança chamas!");

	}

	@Override
	public void metodoAtacar() {
		System.out.println("Atacou bola de fogo!");
	}
}
