package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	public PokemonAgua(String nome, int nivel, String ataque) {
		this.setNome(nome);
	}

	public void metodosurfar() {
		System.out.println(this.getTipo() + " Está surfando!");
	}

	public void canhaoAgua() {
		System.out.println(this.getNome() + " Lançou canhão de água!");
	}

	@Override
	public void metodoAtacar() {
		System.out.println("Atacou bola de agua!");
	}

}
