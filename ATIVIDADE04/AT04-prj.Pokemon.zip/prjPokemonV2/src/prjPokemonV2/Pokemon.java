package prjPokemonV2;

public class Pokemon {
	// Atributos
	private String nome;
	private String tipo;
	private double nivel;
	private int hp;
	private int defesa;

	// Construtores
	Pokemon() {
	}

	public Pokemon(String parametroNome, String parametroTipo, int parametroNivel, int parametroHp,
			int parametroDefesa) {
		this.nome = parametroNome;
		this.tipo = parametroTipo;
		this.nivel = parametroNivel;
		this.hp = parametroHp;
		this.defesa = parametroDefesa;
	}
	// getters and setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getNivel() {
		return nivel;
	}

	public void setNivel(double nivel) {
		this.nivel = nivel;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public void defesa(int defesa) {
		this.defesa = defesa;
	}

	// metodos
	void atacar() {
		System.out.println(nome + " usou um ataque!");
	}

	void evoluir(int nivel) {
		System.out.println(nome + " está evoluindo!");
		System.out.println(nome + " evoluiu!");
	}

	void exibirinfo() {
		System.out.println("Nome: " + this.nome);
		// System.out.println("Tipo: " + this.tipo);
		System.out.println("Nível: " + this.nivel);
		System.out.println("HP: " + this.hp);
		System.out.println("defesa: " + this.defesa);
	}

	public void metodoAtacar() {
		System.out.println("Ataque");

	}

}
