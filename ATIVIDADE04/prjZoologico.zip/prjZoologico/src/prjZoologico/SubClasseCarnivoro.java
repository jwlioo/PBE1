package prjZoologico;

public class SubClasseCarnivoro extends ClasseAnimal{
	//metodo da SubClasse
	public void metodoCacar() {
		System.out.println(this.atributoNome + "esta caçando.");
	}
	@Override
	public void metodoEmitirSom() {
		System.out.println("RUARRRRR");
		
	}


}
