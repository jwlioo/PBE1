package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Usuario;


public class aplicacao {

	public static void main(String[] args) {

		Usuario usuario01 = new Usuario();
		usuario01.setCPF(123456790);
		usuario01.setLivrosEmprestados(0);
		
		Usuario usuario02 = new Usuario();
		usuario02.setCPF(1229376499);
		usuario02.setLivrosEmprestados(0);
		

	}

	public void exibirQuantidadeLivrosEmprestados() {
		System.out.println(
				usuario01.getNome() + " tem " + usuario01.quantidadeLivrosEmprestados() + " livros emprestados.");
		System.out.println(
				usuario02.getNome() + " tem " + usuario02.quantidadeLivrosEmprestados() + " livros emprestados.");

	}

}