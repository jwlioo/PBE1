package br.com.bibiotecasenai.usuarios;

public class Usuario {
	//atributos
	private int CPF;
	private int livrosEmprestados;
	
	//getter & setters
	public int getCPF() {
		return CPF;
	}
	public void setCPF(int cPF) {
		CPF = cPF;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}

}
